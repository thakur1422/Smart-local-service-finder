# Smart Service Finder

Smart Service Finder is a PHP and MySQL web application for discovering local service professionals, booking services, and managing customer-worker communication from role-based dashboards.

The project is built for a local XAMPP environment and includes separate flows for customers, workers, and admins.

## Features

- Public landing page, service catalog, worker search, booking form, and booking chat
- Customer registration, login, dashboard, profile, and booking history
- Worker registration, login, dashboard, job management, profile editing, availability, rates, and profile photo uploads
- Admin dashboard with platform totals, recent users, and recent bookings
- Booking status flow for pending, accepted, rejected, and completed jobs
- Booking-based chat between customers and workers
- Notification records for booking requests and worker responses
- AJAX form submission, live validation, toast feedback, and dashboard refresh behavior
- MySQL schema with categories, users, workers, bookings, messages, notifications, and reviews

## Tech Stack

- Frontend: HTML, CSS, JavaScript
- Backend: PHP 8+
- Database: MySQL / MariaDB
- Local server: XAMPP with Apache and MySQL

## Project Structure

```text
smart-service-finder/
|-- admin/
|   `-- dashboard.php
|-- customer/
|   |-- dashboard.php
|   |-- my-bookings.php
|   `-- profile.php
|-- worker/
|   |-- dashboard.php
|   |-- my-jobs.php
|   `-- profile.php
|-- php/
|   |-- db.php
|   |-- login.php
|   |-- register.php
|   |-- worker_register.php
|   |-- booking.php
|   |-- update_booking.php
|   |-- search_worker.php
|   |-- send_message.php
|   |-- get_messages.php
|   |-- dashboard_snapshot.php
|   `-- response_helpers.php
|-- css/
|   `-- app.css
|-- js/
|   `-- app.js
|-- images/
|-- uploads/
|-- index.html
|-- services.html
|-- search.html
|-- booking.html
|-- chat.html
|-- login.html
|-- worker_login.html
|-- customer_register.html
|-- worker_register.html
`-- service_finder.sql
```

## Database

The database name used by the project is:

```text
service_finder
```

The complete schema and category seed data are included in:

```text
service_finder.sql
```

Core tables:

- `users`
- `categories`
- `workers`
- `bookings`
- `messages`
- `notifications`
- `reviews`

## Local Setup

1. Move or clone the project into your XAMPP `htdocs` folder:

```text
C:\xampp\htdocs\smart-service-finder
```

2. Start Apache and MySQL from the XAMPP Control Panel.

3. Open phpMyAdmin:

```text
http://localhost/phpmyadmin
```

4. Import the database:

- Create a database named `service_finder`, or let the SQL file create it.
- Import `service_finder.sql`.

5. Check the database connection in `php/db.php`:

```php
$host = "localhost";
$user = "root";
$password = "";
$database = "service_finder";
```

Update these values if your local MySQL username or password is different.

6. Open the application:

```text
http://localhost/smart-service-finder/
```

## Test Flow

Customer flow:

1. Register from `customer_register.html`.
2. Log in from `login.html`.
3. Search for a worker from `search.html`.
4. Choose `Book Now` and complete the booking form.
5. Track status from `customer/dashboard.php` or `customer/my-bookings.php`.
6. Open chat after the worker accepts the booking.

Worker flow:

1. Register from `worker_register.html`.
2. Log in from `worker_login.html`.
3. Review pending requests from `worker/dashboard.php`.
4. Accept or reject bookings.
5. Open chat for accepted jobs.
6. Update profile details, availability, rate, category, and photo from `worker/profile.php`.

Admin flow:

1. Log in with a user account whose `role` is set to `admin`.
2. Open `admin/dashboard.php`.
3. Review user, worker, and booking activity.

## Creating an Admin User

The SQL file does not include a default admin account. For local testing, register a normal customer account first, then update its role from phpMyAdmin or MySQL:

```sql
UPDATE users
SET role = 'admin'
WHERE email = 'your-email@example.com';
```

## Notes

- This project is intended for local development and academic or portfolio use.
- Passwords are stored with PHP password hashing.
- Session-based authentication is used for customer, worker, and admin areas.
- Worker profile photos are stored in the `uploads/` directory.
- Some category cards use external stock image URLs.
- For production deployment, move credentials out of `php/db.php`, lock down uploads, add CSRF protection, and review server/database permissions.

## Future Improvements

- Add password reset and email verification
- Add admin CRUD screens for categories and workers
- Add customer review submission UI
- Add worker availability calendar
- Add payment integration
- Add booking completion controls and service history reports

## License

This project is available for personal, academic, and portfolio use. Add a formal license before using it in a public or commercial production setting.
