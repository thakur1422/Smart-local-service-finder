<?php
session_start();
include '../php/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.html');
    exit();
}

$counts = [
    'users' => (int) ($conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'] ?? 0),
    'workers' => (int) ($conn->query("SELECT COUNT(*) AS total FROM workers")->fetch_assoc()['total'] ?? 0),
    'bookings' => (int) ($conn->query("SELECT COUNT(*) AS total FROM bookings")->fetch_assoc()['total'] ?? 0),
];

$users_result = $conn->query("
    SELECT id, name, email, phone, role, city, created_at
    FROM users
    ORDER BY created_at DESC
    LIMIT 10
");

$bookings_result = $conn->query("
    SELECT b.id, customer.name AS customer_name, worker_user.name AS worker_name, b.service_type,
           b.booking_date, b.status, b.estimated_price
    FROM bookings b
    LEFT JOIN users customer ON b.user_id = customer.id
    LEFT JOIN workers w ON b.worker_id = w.id
    LEFT JOIN users worker_user ON w.user_id = worker_user.id
    ORDER BY b.created_at DESC
    LIMIT 10
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php" class="is-active">Admin Dashboard</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Administration</span>
                        <h1 style="margin: 0.8rem 0 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2rem, 4vw, 3.25rem);">
                            Platform Overview
                        </h1>
                        <p>Monitor user growth, worker participation, and recent booking activity.</p>
                    </div>
                </div>

                <div class="stats-row">
                    <div class="stat-block">
                        <strong><?= $counts['users'] ?></strong>
                        <span>Total users</span>
                    </div>
                    <div class="stat-block">
                        <strong><?= $counts['workers'] ?></strong>
                        <span>Registered workers</span>
                    </div>
                    <div class="stat-block">
                        <strong><?= $counts['bookings'] ?></strong>
                        <span>Total bookings</span>
                    </div>
                </div>
            </section>

            <section class="dashboard-grid">
                <div class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">User management</span>
                            <h2 style="margin-top: 0.75rem;">Latest users</h2>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th>City</th>
                                    <th>Joined</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($user = $users_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['name']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td><?= htmlspecialchars($user['phone']) ?></td>
                                        <td><span class="status <?= $user['role'] === 'admin' ? 'rejected' : 'completed' ?>"><?= htmlspecialchars($user['role']) ?></span></td>
                                        <td><?= htmlspecialchars($user['city'] ?? '-') ?></td>
                                        <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Booking management</span>
                            <h2 style="margin-top: 0.75rem;">Recent bookings</h2>
                        </div>
                    </div>

                    <div class="table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Booking</th>
                                    <th>Customer</th>
                                    <th>Worker</th>
                                    <th>Service</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($booking = $bookings_result->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?= (int) $booking['id'] ?></td>
                                        <td><?= htmlspecialchars($booking['customer_name'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($booking['worker_name'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($booking['service_type']) ?></td>
                                        <td><?= date('M j, Y g:i A', strtotime($booking['booking_date'])) ?></td>
                                        <td><span class="status <?= htmlspecialchars($booking['status']) ?>"><?= ucfirst(htmlspecialchars($booking['status'])) ?></span></td>
                                        <td>Rs. <?= number_format((float) ($booking['estimated_price'] ?? 0), 0) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </main>
</body>
</html>
