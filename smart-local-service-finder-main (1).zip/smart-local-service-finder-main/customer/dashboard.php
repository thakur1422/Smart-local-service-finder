<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.html');
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT
        u.name,
        COALESCE(COUNT(b.id), 0) AS total_bookings,
        COALESCE(SUM(CASE WHEN b.status = 'pending' THEN 1 ELSE 0 END), 0) AS pending_bookings,
        COALESCE(SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END), 0) AS completed_bookings
    FROM users u
    LEFT JOIN bookings b ON b.user_id = u.id
    WHERE u.id = ?
    GROUP BY u.id
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$overview = $stmt->get_result()->fetch_assoc();
$stmt->close();

$recent_stmt = $conn->prepare("
    SELECT b.*, w.skill, worker_user.name AS worker_name
    FROM bookings b
    LEFT JOIN workers w ON b.worker_id = w.id
    LEFT JOIN users worker_user ON w.user_id = worker_user.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
    LIMIT 5
");
$recent_stmt->bind_param("i", $user_id);
$recent_stmt->execute();
$recent_bookings = $recent_stmt->get_result();

$notif_stmt = $conn->prepare("
    SELECT message, status, created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 5
");
$notif_stmt->bind_param("i", $user_id);
$notif_stmt->execute();
$notifications = $notif_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page" data-dashboard-role="customer" data-dashboard-endpoint="../php/dashboard_snapshot.php">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php" class="is-active">Dashboard</a>
                <a href="my-bookings.php">My Bookings</a>
                <a href="profile.php">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <span class="ui-eyebrow">Customer dashboard</span>
                <div class="panel-heading" style="margin-top: 1rem;">
                    <div>
                        <h1 style="margin: 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2.2rem, 4vw, 3.5rem);">
                            Welcome back, <?= htmlspecialchars($overview['name'] ?? 'Customer') ?>
                        </h1>
                        <p>Manage bookings, review service updates, and explore professionals from one organized place.</p>
                    </div>
                    <a href="../search.html" class="btn-primary">Book New Service</a>
                </div>

                    <div class="stats-row">
                    <div class="stat-block">
                        <strong data-stat="total_bookings"><?= (int) ($overview['total_bookings'] ?? 0) ?></strong>
                        <span>Total bookings</span>
                    </div>
                    <div class="stat-block">
                        <strong data-stat="pending_bookings"><?= (int) ($overview['pending_bookings'] ?? 0) ?></strong>
                        <span>Pending services</span>
                    </div>
                    <div class="stat-block">
                        <strong data-stat="completed_bookings"><?= (int) ($overview['completed_bookings'] ?? 0) ?></strong>
                        <span>Completed jobs</span>
                    </div>
                </div>
            </section>

            <section class="dashboard-grid">
                <div class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Recent activity</span>
                            <h2 style="margin-top: 0.75rem;">Recent Bookings</h2>
                        </div>
                        <a href="my-bookings.php" class="subtle-link">View all bookings</a>
                    </div>

                    <div class="info-list" id="customer-recent-bookings">
                        <?php if ($recent_bookings->num_rows === 0): ?>
                            <div class="list-empty">
                                No bookings yet. Start by exploring available services.
                            </div>
                        <?php else: ?>
                            <?php while ($booking = $recent_bookings->fetch_assoc()): ?>
                                <article class="info-item">
                                    <div class="panel-heading" style="margin-bottom: 0.5rem;">
                                        <div>
                                            <h3><?= htmlspecialchars($booking['service_type']) ?></h3>
                                            <p>Worker: <?= htmlspecialchars($booking['worker_name'] ?? 'To be assigned') ?></p>
                                        </div>
                                        <span class="status <?= htmlspecialchars($booking['status']) ?>">
                                            <?= ucfirst(htmlspecialchars($booking['status'])) ?>
                                        </span>
                                    </div>
                                    <div class="meta-row">
                                        <span class="meta-pill">Booking #<?= (int) $booking['id'] ?></span>
                                        <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($booking['booking_date'])) ?></span>
                                    </div>
                                </article>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="stack-grid">
                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Quick actions</span>
                                <h2 style="margin-top: 0.75rem;">What would you like to do?</h2>
                            </div>
                        </div>
                        <div class="form-stack">
                            <a href="../search.html" class="btn-primary">Find Professionals</a>
                            <a href="my-bookings.php" class="btn btn-secondary">Manage Bookings</a>
                            <a href="profile.php" class="btn btn-secondary">Update Profile</a>
                        </div>
                    </section>

                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Notifications</span>
                                <h2 style="margin-top: 0.75rem;">Latest updates</h2>
                            </div>
                        </div>
                        <div class="info-list" id="customer-notifications">
                            <?php if ($notifications->num_rows === 0): ?>
                                <div class="list-empty">No notifications yet.</div>
                            <?php else: ?>
                                <?php while ($notification = $notifications->fetch_assoc()): ?>
                                    <article class="info-item">
                                        <h4 style="margin-bottom: 0.35rem;">
                                            <?= htmlspecialchars($notification['status'] === 'unread' ? 'New update' : 'Earlier update') ?>
                                        </h4>
                                        <p><?= htmlspecialchars($notification['message']) ?></p>
                                        <div class="meta-row">
                                            <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($notification['created_at'])) ?></span>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </section>
                </div>
            </section>
        </div>
    </main>
    <script src="../js/app.js"></script>
</body>
</html>
