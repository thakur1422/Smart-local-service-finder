<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.html');
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

$user_stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();
$user_stmt->close();

$stmt = $conn->prepare("
    SELECT b.*, w.skill, worker_user.name AS worker_name
    FROM bookings b
    LEFT JOIN workers w ON b.worker_id = w.id
    LEFT JOIN users worker_user ON w.user_id = worker_user.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bookings = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="my-bookings.php" class="is-active">My Bookings</a>
                <a href="profile.php">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Bookings overview</span>
                        <h1 style="margin: 0.8rem 0 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2rem, 4vw, 3.25rem);">
                            <?= htmlspecialchars($user['name'] ?? 'Customer') ?>'s Bookings
                        </h1>
                    </div>
                    <a href="../search.html" class="btn-primary">Book Another Service</a>
                </div>
            </section>

            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Booking history</span>
                        <h2 style="margin-top: 0.75rem;">All service requests</h2>
                    </div>
                </div>

                <div class="info-list">
                    <?php if ($bookings->num_rows === 0): ?>
                        <div class="list-empty">
                            No bookings yet. Use the search page to request your first service.
                        </div>
                    <?php else: ?>
                        <?php while ($booking = $bookings->fetch_assoc()): ?>
                            <article class="info-item">
                                <div class="panel-heading" style="margin-bottom: 0.5rem;">
                                    <div>
                                        <h3><?= htmlspecialchars($booking['service_type']) ?></h3>
                                        <p>Worker: <?= htmlspecialchars($booking['worker_name'] ?? 'To be assigned') ?></p>
                                    </div>
                                    <span class="status <?= htmlspecialchars($booking['status']) ?>">
                                        <?= ucfirst(htmlspecialchars($booking['status'])) ?>
                                    </span>
                                </div>

                                <div class="meta-row">
                                    <span class="meta-pill">Booking #<?= (int) $booking['id'] ?></span>
                                    <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($booking['booking_date'])) ?></span>
                                    <?php if (!empty($booking['estimated_price'])): ?>
                                        <span class="meta-pill">Rs. <?= number_format((float) $booking['estimated_price'], 0) ?></span>
                                    <?php endif; ?>
                                </div>

                                <?php if ($booking['status'] === 'accepted'): ?>
                                    <div class="actions-row">
                                        <a href="../chat.html?booking_id=<?= (int) $booking['id'] ?>" class="btn-primary">Open Chat</a>
                                    </div>
                                <?php endif; ?>
                            </article>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>
</body>
</html>
