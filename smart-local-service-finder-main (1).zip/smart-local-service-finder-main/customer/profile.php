<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: ../login.html');
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $city = trim($_POST['city'] ?? '');

    if ($name !== '' && $phone !== '' && $email !== '') {
        $check = $conn->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id <> ?");
        $check->bind_param("ssi", $email, $phone, $user_id);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $check->close();
            header('Location: profile.php?error=duplicate');
            exit();
        }

        $check->close();

        $update = $conn->prepare("UPDATE users SET name = ?, phone = ?, email = ?, city = ? WHERE id = ?");
        $update->bind_param("ssssi", $name, $phone, $email, $city, $user_id);
        $update->execute();
        $update->close();
        header('Location: profile.php?updated=1');
        exit();
    }
}

$stmt = $conn->prepare("SELECT name, email, phone, city, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Profile - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="my-bookings.php">My Bookings</a>
                <a href="profile.php" class="is-active">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Profile settings</span>
                        <h1 style="margin: 0.8rem 0 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2rem, 4vw, 3.25rem);">
                            Customer Profile
                        </h1>
                        <p>Keep your contact details current for smoother bookings and notifications.</p>
                    </div>
                    <?php if (isset($_GET['updated'])): ?>
                        <span class="status completed">Profile updated</span>
                    <?php elseif (isset($_GET['error']) && $_GET['error'] === 'duplicate'): ?>
                        <span class="status rejected">Email or phone already in use</span>
                    <?php endif; ?>
                </div>
            </section>

            <section class="dashboard-grid">
                <div class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Edit details</span>
                            <h2 style="margin-top: 0.75rem;">Your account information</h2>
                        </div>
                    </div>

                    <form method="POST" class="form-stack" data-live-validate>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="profile-name">Full Name</label>
                                <input type="text" id="profile-name" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>" required data-validate="name">
                            </div>
                            <div class="form-group">
                                <label for="profile-phone">Phone Number</label>
                                <input type="text" id="profile-phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required data-validate="phone">
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="profile-email">Email Address</label>
                                <input type="email" id="profile-email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required data-validate="email">
                            </div>
                            <div class="form-group">
                                <label for="profile-city">City</label>
                                <input type="text" id="profile-city" name="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>" placeholder="Enter your city">
                            </div>
                        </div>

                        <button type="submit" class="btn-primary">Save Changes</button>
                    </form>
                </div>

                <aside class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Account summary</span>
                            <h2 style="margin-top: 0.75rem;">Profile snapshot</h2>
                        </div>
                    </div>
                    <div class="info-list">
                        <article class="info-item">
                            <h4>Name</h4>
                            <p><?= htmlspecialchars($user['name'] ?? '') ?></p>
                        </article>
                        <article class="info-item">
                            <h4>Email</h4>
                            <p><?= htmlspecialchars($user['email'] ?? '') ?></p>
                        </article>
                        <article class="info-item">
                            <h4>Joined</h4>
                            <p><?= !empty($user['created_at']) ? date('M j, Y', strtotime($user['created_at'])) : 'Recently' ?></p>
                        </article>
                    </div>
                </aside>
            </section>
        </div>
    </main>
    <script src="../js/app.js"></script>
</body>
</html>
