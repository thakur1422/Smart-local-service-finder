(() => {
  const toastStack = document.createElement('div');
  toastStack.className = 'toast-stack';
  let dashboardRefreshInFlight = false;
  document.addEventListener('DOMContentLoaded', () => {
    document.body.appendChild(toastStack);
    initLiveValidation();
    initAjaxForms();
    initDashboardRefresh();
  });

  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast is-${type}`;
    toast.textContent = message;
    toastStack.appendChild(toast);

    window.setTimeout(() => {
      toast.remove();
    }, 3500);
  }

  function getFieldErrorElement(field) {
    let error = field.parentElement.querySelector('.field-error');
    if (!error) {
      error = document.createElement('span');
      error.className = 'field-error';
      error.hidden = true;
      field.parentElement.appendChild(error);
    }
    return error;
  }

  function getValidationMessage(field) {
    const value = field.value.trim();
    const validationType = field.dataset.validate || field.type || field.tagName.toLowerCase();

    if (field.required && value === '') {
      return 'This field is required.';
    }

    if (value === '') {
      return '';
    }

    switch (validationType) {
      case 'email':
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? '' : 'Enter a valid email address.';
      case 'phone':
        return /^[0-9+\-\s]{7,20}$/.test(value) ? '' : 'Enter a valid phone number.';
      case 'contact':
        return value.length >= 4 ? '' : 'Enter your email address or phone number.';
      case 'password':
        return value.length >= 6 ? '' : 'Password should be at least 6 characters.';
      case 'number':
        return Number(value) >= 0 ? '' : 'Enter a valid number.';
      case 'select':
        return value ? '' : 'Please choose an option.';
      case 'date':
        return value ? '' : 'Please select a date.';
      case 'name':
        return value.length >= 2 ? '' : 'Enter your full name.';
      default:
        return value.length >= 2 || field.tagName === 'TEXTAREA' ? '' : 'Please enter at least 2 characters.';
    }
  }

  function updateFieldState(field) {
    const errorMessage = getValidationMessage(field);
    const errorElement = getFieldErrorElement(field);

    if (errorMessage) {
      field.classList.add('field-invalid');
      field.classList.remove('field-valid');
      errorElement.textContent = errorMessage;
      errorElement.hidden = false;
      return false;
    }

    field.classList.remove('field-invalid');
    if (field.value.trim() !== '') {
      field.classList.add('field-valid');
    } else {
      field.classList.remove('field-valid');
    }
    errorElement.textContent = '';
    errorElement.hidden = true;
    return true;
  }

  function getValidatableFields(form) {
    return Array.from(form.querySelectorAll('input, select, textarea')).filter((field) => {
      return field.name && (field.required || field.dataset.validate);
    });
  }

  function validateForm(form) {
    const fields = getValidatableFields(form);
    return fields.every((field) => updateFieldState(field));
  }

  function setFormFeedback(form, message, type) {
    const feedback = form.parentElement.querySelector('[data-form-feedback]') || form.querySelector('[data-form-feedback]');
    if (!feedback) {
      showToast(message, type === 'error' ? 'error' : 'success');
      return;
    }

    feedback.hidden = false;
    feedback.className = `form-status is-${type}`;
    feedback.textContent = message;
  }

  function clearFormFeedback(form) {
    const feedback = form.parentElement.querySelector('[data-form-feedback]') || form.querySelector('[data-form-feedback]');
    if (feedback) {
      feedback.hidden = true;
      feedback.textContent = '';
      feedback.className = 'form-status';
    }
  }

  function setSubmitState(form, isLoading) {
    const submitButton = form.querySelector('[type="submit"]');
    if (!submitButton) return;

    if (!submitButton.dataset.defaultText) {
      submitButton.dataset.defaultText = submitButton.textContent;
    }

    form.classList.toggle('is-loading', isLoading);
    submitButton.disabled = isLoading;
    submitButton.textContent = isLoading
      ? (submitButton.dataset.loadingText || 'Please wait...')
      : submitButton.dataset.defaultText;
  }

  function initLiveValidation() {
    const forms = document.querySelectorAll('form[data-live-validate], form[data-ajax-form]');
    forms.forEach((form) => {
      getValidatableFields(form).forEach((field) => {
        if (field.dataset.validationBound === 'true') {
          return;
        }

        field.dataset.validationBound = 'true';
        field.addEventListener('blur', () => updateFieldState(field));
        field.addEventListener('input', () => {
          if (field.classList.contains('field-invalid') || field.classList.contains('field-valid')) {
            updateFieldState(field);
          }
        });
      });
    });
  }

  async function parseResponse(response) {
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch (_error) {
      return {
        ok: response.ok,
        message: text || 'Unexpected response received.',
      };
    }
  }

  function initAjaxForms() {
    const forms = document.querySelectorAll('form[data-ajax-form]');
    forms.forEach((form) => {
      if (form.dataset.ajaxBound === 'true') {
        return;
      }

      form.dataset.ajaxBound = 'true';
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        clearFormFeedback(form);

        if (!validateForm(form)) {
          setFormFeedback(form, 'Please fix the highlighted fields and try again.', 'error');
          return;
        }

        setSubmitState(form, true);

        try {
          const actionUrl = form.getAttribute('action') || window.location.href;
          const response = await fetch(actionUrl, {
            method: form.method || 'POST',
            headers: {
              'X-Requested-With': 'XMLHttpRequest',
              'Accept': 'application/json',
            },
            body: new FormData(form),
          });

          const data = await parseResponse(response);

          if (!response.ok || !data.ok) {
            setFormFeedback(form, data.message || 'Something went wrong.', 'error');
            showToast(data.message || 'Something went wrong.', 'error');
            return;
          }

          setFormFeedback(form, data.message || 'Saved successfully.', 'success');
          showToast(data.message || 'Saved successfully.', 'success');

          if (form.hasAttribute('data-booking-action')) {
            await refreshDashboardSnapshot(true);
            if (document.body.dataset.dashboardRole === 'worker') {
              window.setTimeout(() => {
                window.location.reload();
              }, 250);
              return;
            }
          } else if (data.redirect) {
            window.setTimeout(() => {
              window.location.href = data.redirect;
            }, 700);
          }
        } catch (_error) {
          const message = 'Unable to complete the request right now.';
          setFormFeedback(form, message, 'error');
          showToast(message, 'error');
        } finally {
          setSubmitState(form, false);
        }
      });
    });
  }

  function renderCustomerBookings(items) {
    const container = document.getElementById('customer-recent-bookings');
    if (!container) return;

    if (!items.length) {
      container.innerHTML = '<div class="list-empty">No bookings yet. Start by exploring available services.</div>';
      return;
    }

    container.innerHTML = items.map((booking) => `
      <article class="info-item">
        <div class="panel-heading" style="margin-bottom: 0.5rem;">
          <div>
            <h3>${escapeHtml(booking.service_type)}</h3>
            <p>Worker: ${escapeHtml(booking.worker_name || 'To be assigned')}</p>
          </div>
          <span class="status ${escapeHtml(booking.status)}">${capitalize(booking.status)}</span>
        </div>
        <div class="meta-row">
          <span class="meta-pill">Booking #${Number(booking.id)}</span>
          <span class="meta-pill">${formatDateTime(booking.booking_date)}</span>
        </div>
      </article>
    `).join('');
  }

  function renderWorkerPendingJobs(items) {
    const container = document.getElementById('worker-pending-jobs');
    const updateBookingEndpoint = document.body.dataset.updateBookingEndpoint || '../php/update_booking.php';
    if (!container) return;

    if (!items.length) {
      container.innerHTML = '<div class="list-empty">No pending booking requests right now.</div>';
      return;
    }

    container.innerHTML = items.map((job) => `
      <article class="info-item">
        <div class="panel-heading" style="margin-bottom: 0.5rem;">
          <div>
            <h3>${escapeHtml(job.service_type)}</h3>
            <p>Customer: ${escapeHtml(job.customer_name)}</p>
          </div>
          <span class="status pending">Pending</span>
        </div>
        <div class="meta-row">
          <span class="meta-pill">Booking #${Number(job.id)}</span>
          <span class="meta-pill">${formatDateTime(job.booking_date)}</span>
          <span class="meta-pill">${escapeHtml(job.customer_phone)}</span>
        </div>
        <div class="actions-row">
          <form method="POST" action="${escapeHtml(updateBookingEndpoint)}" data-ajax-form data-booking-action>
            <input type="hidden" name="id" value="${Number(job.id)}">
            <input type="hidden" name="action" value="accept">
            <button type="submit" class="btn-success" data-loading-text="Accepting...">Accept</button>
          </form>
          <form method="POST" action="${escapeHtml(updateBookingEndpoint)}" data-ajax-form data-booking-action>
            <input type="hidden" name="id" value="${Number(job.id)}">
            <input type="hidden" name="action" value="reject">
            <button type="submit" class="btn btn-secondary" data-loading-text="Rejecting...">Reject</button>
          </form>
        </div>
      </article>
    `).join('');

    initAjaxForms();
  }

  function renderWorkerAcceptedJobs(items) {
    const container = document.getElementById('worker-accepted-jobs');
    if (!container) return;

    if (!items.length) {
      container.innerHTML = '<div class="list-empty">No accepted or completed jobs yet.</div>';
      return;
    }

    container.innerHTML = items.map((job) => `
      <article class="info-item">
        <div class="panel-heading" style="margin-bottom: 0.5rem;">
          <div>
            <h3>${escapeHtml(job.service_type)}</h3>
            <p>Customer: ${escapeHtml(job.customer_name)}</p>
          </div>
          <span class="status ${escapeHtml(job.status)}">${capitalize(job.status)}</span>
        </div>
        <div class="meta-row">
          <span class="meta-pill">Booking #${Number(job.id)}</span>
          <span class="meta-pill">${formatDateTime(job.booking_date)}</span>
        </div>
        ${job.status === 'accepted' ? `<div class="actions-row"><a href="../chat.html?booking_id=${Number(job.id)}" class="btn-primary">Open Chat</a></div>` : ''}
      </article>
    `).join('');
  }

  function renderNotifications(containerId, notifications) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!notifications.length) {
      container.innerHTML = '<div class="list-empty">No notifications yet.</div>';
      return;
    }

    container.innerHTML = notifications.map((notification) => `
      <article class="info-item">
        <h4 style="margin-bottom: 0.35rem;">${notification.status === 'unread' ? 'New update' : 'Earlier update'}</h4>
        <p>${escapeHtml(notification.message)}</p>
        <div class="meta-row">
          <span class="meta-pill">${formatDateTime(notification.created_at)}</span>
        </div>
      </article>
    `).join('');
  }

  function applyDashboardSnapshot(snapshot) {
    if (snapshot.role === 'user') {
      updateStat('total_bookings', snapshot.stats.total_bookings);
      updateStat('pending_bookings', snapshot.stats.pending_bookings);
      updateStat('completed_bookings', snapshot.stats.completed_bookings);
      renderCustomerBookings(snapshot.recent_bookings || []);
      renderNotifications('customer-notifications', snapshot.notifications || []);
    }

    if (snapshot.role === 'worker') {
      updateStat('pending_jobs', snapshot.stats.pending_jobs);
      updateStat('accepted_jobs', snapshot.stats.accepted_jobs);
      updateStat('price_per_hour', `Rs. ${Number(snapshot.stats.price_per_hour ?? 0).toLocaleString('en-IN')}/hr`);
      renderWorkerPendingJobs(snapshot.pending_jobs || []);
      renderWorkerAcceptedJobs(snapshot.accepted_jobs || []);
      renderNotifications('worker-notifications', snapshot.notifications || []);
    }
  }

  function updateStat(name, value) {
    const target = document.querySelector(`[data-stat="${name}"]`);
    if (target) {
      target.textContent = typeof value === 'number' ? value.toLocaleString('en-IN') : value;
    }
  }

  async function refreshDashboardSnapshot(forceFresh = false) {
    const dashboardRole = document.body.dataset.dashboardRole;
    const endpoint = document.body.dataset.dashboardEndpoint;
    if (!dashboardRole || !endpoint || document.hidden || dashboardRefreshInFlight) return;

    dashboardRefreshInFlight = true;
    try {
      const requestUrl = new URL(endpoint, window.location.href);
      if (forceFresh) {
        requestUrl.searchParams.set('_ts', String(Date.now()));
      }

      const response = await fetch(requestUrl, {
        cache: 'no-store',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Accept': 'application/json',
        },
      });
      const data = await response.json();
      if (response.ok && data.ok) {
        applyDashboardSnapshot(data);
      }
    } catch (_error) {
      // Silent background refresh failure.
    } finally {
      dashboardRefreshInFlight = false;
    }
  }

  function initDashboardRefresh() {
    if (!document.body.dataset.dashboardRole) {
      return;
    }

    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        refreshDashboardSnapshot();
      }
    });

    window.setInterval(refreshDashboardSnapshot, 20000);
  }

  function formatDateTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return date.toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  }

  function capitalize(value) {
    return String(value || '').charAt(0).toUpperCase() + String(value || '').slice(1);
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }
})();
