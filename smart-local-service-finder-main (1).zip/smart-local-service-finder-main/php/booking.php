<?php
session_start();
include("db.php");
require_once("response_helpers.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_with_error("Invalid request.", 405);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    respond_with_error("Please sign in as a customer to book services.", 401, [
        'redirect' => '../login.html',
    ]);
}

$service_type = trim($_POST['service'] ?? '');
$worker_user_id = (int) ($_POST['worker_id'] ?? 0);
$date = trim($_POST['date'] ?? '');
$time_slot = trim($_POST['time_slot'] ?? '');
$address = trim($_POST['address'] ?? '');
$notes = trim($_POST['notes'] ?? '');
$estimated_price = (float) ($_POST['estimated_price'] ?? 0);
$user_id = (int) $_SESSION['user_id'];

if ($service_type === '' || $worker_user_id <= 0 || $date === '' || $time_slot === '' || $address === '') {
    respond_with_error("Please complete the booking form.");
}

$worker_stmt = $conn->prepare("SELECT id FROM workers WHERE user_id = ? LIMIT 1");
$worker_stmt->bind_param("i", $worker_user_id);
$worker_stmt->execute();
$worker = $worker_stmt->get_result()->fetch_assoc();
$worker_stmt->close();

if (!$worker) {
    respond_with_error("Selected worker not found.", 404);
}

$slot_start = explode('-', $time_slot)[0] . ':00';
$booking_date = $date . ' ' . $slot_start;
$worker_id = (int) $worker['id'];

$stmt = $conn->prepare("
    INSERT INTO bookings (user_id, worker_id, service_type, booking_date, time_slot, address, notes, status, estimated_price)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
");
$stmt->bind_param("iisssssd", $user_id, $worker_id, $service_type, $booking_date, $time_slot, $address, $notes, $estimated_price);

if ($stmt->execute()) {
    $booking_id = $conn->insert_id;
    $notification = "New booking #{$booking_id} for {$service_type} on {$date} ({$time_slot}).";
    $notif_stmt = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    $notif_stmt->bind_param("is", $worker_user_id, $notification);
    $notif_stmt->execute();
    $notif_stmt->close();

    respond_with_success("Booking confirmed successfully.", "../customer/my-bookings.php", [
        'booking_id' => $booking_id,
    ]);
} else {
    respond_with_error("Booking failed: " . $stmt->error, 500);
}

$stmt->close();
?>
