<?php
session_start();
include 'db.php';
require_once 'response_helpers.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    respond_with_error('Unauthorized.', 401);
}

$user_id = (int) $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role === 'user') {
    $stats_stmt = $conn->prepare("
        SELECT
            COALESCE(COUNT(b.id), 0) AS total_bookings,
            COALESCE(SUM(CASE WHEN b.status = 'pending' THEN 1 ELSE 0 END), 0) AS pending_bookings,
            COALESCE(SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END), 0) AS completed_bookings
        FROM users u
        LEFT JOIN bookings b ON b.user_id = u.id
        WHERE u.id = ?
        GROUP BY u.id
    ");
    $stats_stmt->bind_param("i", $user_id);
    $stats_stmt->execute();
    $stats = $stats_stmt->get_result()->fetch_assoc() ?: [
        'total_bookings' => 0,
        'pending_bookings' => 0,
        'completed_bookings' => 0,
    ];
    $stats_stmt->close();

    $bookings_stmt = $conn->prepare("
        SELECT b.id, b.service_type, b.status, b.booking_date, worker_user.name AS worker_name
        FROM bookings b
        LEFT JOIN workers w ON b.worker_id = w.id
        LEFT JOIN users worker_user ON w.user_id = worker_user.id
        WHERE b.user_id = ?
        ORDER BY b.created_at DESC
        LIMIT 5
    ");
    $bookings_stmt->bind_param("i", $user_id);
    $bookings_stmt->execute();
    $bookings_result = $bookings_stmt->get_result();
    $recent_bookings = [];
    while ($row = $bookings_result->fetch_assoc()) {
        $recent_bookings[] = $row;
    }
    $bookings_stmt->close();

    $notifications_stmt = $conn->prepare("
        SELECT message, status, created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $notifications_stmt->bind_param("i", $user_id);
    $notifications_stmt->execute();
    $notifications_result = $notifications_stmt->get_result();
    $notifications = [];
    while ($row = $notifications_result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $notifications_stmt->close();

    send_json_response([
        'ok' => true,
        'role' => 'user',
        'stats' => $stats,
        'recent_bookings' => $recent_bookings,
        'notifications' => $notifications,
    ]);
}

if ($role === 'worker') {
    $worker_stmt = $conn->prepare("SELECT id, price_per_hour FROM workers WHERE user_id = ?");
    $worker_stmt->bind_param("i", $user_id);
    $worker_stmt->execute();
    $worker = $worker_stmt->get_result()->fetch_assoc();
    $worker_stmt->close();

    if (!$worker) {
        respond_with_error('Worker profile not found.', 404);
    }

    $worker_id = (int) $worker['id'];

    $stats_stmt = $conn->prepare("
        SELECT
            COUNT(*) AS total_jobs,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_jobs,
            SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) AS accepted_jobs,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_jobs
        FROM bookings
        WHERE worker_id = ?
    ");
    $stats_stmt->bind_param("i", $worker_id);
    $stats_stmt->execute();
    $stats = $stats_stmt->get_result()->fetch_assoc() ?: [
        'total_jobs' => 0,
        'pending_jobs' => 0,
        'accepted_jobs' => 0,
        'completed_jobs' => 0,
    ];
    $stats_stmt->close();
    $stats['price_per_hour'] = (float) ($worker['price_per_hour'] ?? 0);

    $pending_stmt = $conn->prepare("
        SELECT b.id, b.service_type, b.booking_date, u.name AS customer_name, u.phone AS customer_phone
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        WHERE b.worker_id = ? AND b.status = 'pending'
        ORDER BY b.created_at DESC
        LIMIT 5
    ");
    $pending_stmt->bind_param("i", $worker_id);
    $pending_stmt->execute();
    $pending_result = $pending_stmt->get_result();
    $pending_jobs = [];
    while ($row = $pending_result->fetch_assoc()) {
        $pending_jobs[] = $row;
    }
    $pending_stmt->close();

    $accepted_stmt = $conn->prepare("
        SELECT b.id, b.service_type, b.status, b.booking_date, u.name AS customer_name
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        WHERE b.worker_id = ? AND b.status IN ('accepted', 'completed')
        ORDER BY b.created_at DESC
        LIMIT 5
    ");
    $accepted_stmt->bind_param("i", $worker_id);
    $accepted_stmt->execute();
    $accepted_result = $accepted_stmt->get_result();
    $accepted_jobs = [];
    while ($row = $accepted_result->fetch_assoc()) {
        $accepted_jobs[] = $row;
    }
    $accepted_stmt->close();

    $notifications_stmt = $conn->prepare("
        SELECT message, status, created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $notifications_stmt->bind_param("i", $user_id);
    $notifications_stmt->execute();
    $notifications_result = $notifications_stmt->get_result();
    $notifications = [];
    while ($row = $notifications_result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $notifications_stmt->close();

    send_json_response([
        'ok' => true,
        'role' => 'worker',
        'stats' => $stats,
        'pending_jobs' => $pending_jobs,
        'accepted_jobs' => $accepted_jobs,
        'notifications' => $notifications,
    ]);
}

respond_with_error('Dashboard refresh is not supported for this role.', 403);
