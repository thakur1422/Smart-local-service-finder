<?php
session_start();
include("db.php");

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user_id = (int) $_SESSION['user_id'];
$booking_id = (int) ($_GET['booking_id'] ?? 0);

if ($booking_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid booking']);
    exit();
}

$access_stmt = $conn->prepare("
    SELECT b.id, b.user_id AS customer_id, w.user_id AS worker_user_id
    FROM bookings b
    JOIN workers w ON b.worker_id = w.id
    WHERE b.id = ?
");
$access_stmt->bind_param("i", $booking_id);
$access_stmt->execute();
$booking = $access_stmt->get_result()->fetch_assoc();
$access_stmt->close();

if (!$booking || ($booking['customer_id'] != $user_id && $booking['worker_user_id'] != $user_id)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$stmt = $conn->prepare("
    SELECT sender_id, message, created_at
    FROM messages
    WHERE booking_id = ?
    ORDER BY created_at ASC
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $row['is_current_user'] = ((int) $row['sender_id'] === $user_id);
    $messages[] = $row;
}

echo json_encode($messages);
$stmt->close();
?>
