<?php
session_start();
include("db.php");
require_once("response_helpers.php");

function sanitize_next_redirect(?string $next): ?string
{
    $next = trim((string) $next);
    if ($next === '') {
        return null;
    }

    if (preg_match('/^(?:[a-z]+:)?\/\//i', $next)) {
        return null;
    }

    if (!str_starts_with($next, '/')) {
        return null;
    }

    $script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $app_root = preg_replace('#/php/[^/]*$#', '', $script_name);
    $app_root = $app_root === '' ? '' : rtrim($app_root, '/');
    if ($app_root !== '' && !str_starts_with($next, $app_root . '/')) {
        return null;
    }

    return $next;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $login_input = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $next = sanitize_next_redirect($_POST['next'] ?? null);

    if (empty($login_input) || empty($password)) {
        respond_with_error("Please fill all fields.");
    }

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email=? OR phone=?");
    $stmt->bind_param("ss", $login_input, $login_input);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        respond_with_error("User not found. Please register first.", 404);
    }

    $stmt->bind_result($user_id, $hashed_password, $role);
    if (!$stmt->fetch()) {
        respond_with_error("Database fetch error.", 500);
    }

    if (!is_string($hashed_password)) {
        respond_with_error("Invalid password data in database.", 500);
    }

    if (password_verify($password, $hashed_password)) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user_id;
        $_SESSION['role'] = $role;

        if ($role === 'worker') {
            $redirect = $next ?: "../worker/dashboard.php";
        } elseif ($role === 'user') {
            $redirect = $next ?: "../customer/dashboard.php";
        } else {
            $redirect = "../admin/dashboard.php";
        }

        respond_with_success("Signed in successfully.", $redirect, [
            'role' => $role,
        ]);
    } else {
        respond_with_error("Invalid password. Please try again.", 401);
    }
} else {
    header("Location: ../login.html");
    exit();
}
?>

