<?php
include("db.php");
require_once("response_helpers.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        respond_with_error("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond_with_error("Invalid email address.");
    }

    // Check if exists
    $check = $conn->prepare("SELECT id FROM users WHERE email=? OR phone=?");
    $check->bind_param("ss", $email, $phone);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        respond_with_error("Email or phone already registered.", 409);
    }
    $check->close();

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $role = 'user';
    $sql = "INSERT INTO users (name, email, phone, password, role, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        respond_with_error("Unable to prepare registration request.", 500);
    }
    $stmt->bind_param("sssss", $name, $email, $phone, $passwordHash, $role);

    if ($stmt->execute()) {
        respond_with_success("Customer account created successfully. Please sign in.", "../login.html");
    } else {
        respond_with_error("Registration failed: " . $stmt->error, 500);
    }
    $stmt->close();
}

$conn->close();
?>

