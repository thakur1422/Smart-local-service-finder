<?php

function normalize_redirect_path(?string $redirect): ?string
{
    if ($redirect === null || $redirect === '') {
        return $redirect;
    }

    if (preg_match('/^(?:[a-z]+:)?\/\//i', $redirect) || str_starts_with($redirect, '/')) {
        return $redirect;
    }

    $script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $script_dir = $script_name !== '' ? preg_replace('#/[^/]*$#', '', $script_name) : '';
    $base_segments = array_values(array_filter(explode('/', trim((string) $script_dir, '/')), 'strlen'));

    foreach (explode('/', str_replace('\\', '/', $redirect)) as $segment) {
        if ($segment === '' || $segment === '.') {
            continue;
        }

        if ($segment === '..') {
            array_pop($base_segments);
            continue;
        }

        $base_segments[] = $segment;
    }

    return '/' . implode('/', $base_segments);
}

function wants_json_response(): bool
{
    $requested_with = $_SERVER['HTTP_X_REQUESTED_WITH'] ?? '';
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';

    return strtolower($requested_with) === 'xmlhttprequest'
        || str_contains(strtolower($accept), 'application/json');
}

function send_json_response(array $payload, int $status_code = 200): void
{
    http_response_code($status_code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit();
}

function respond_with_error(string $message, int $status_code = 400, array $extra = []): void
{
    if (isset($extra['redirect']) && is_string($extra['redirect'])) {
        $extra['redirect'] = normalize_redirect_path($extra['redirect']);
    }

    if (wants_json_response()) {
        send_json_response(array_merge([
            'ok' => false,
            'message' => $message,
        ], $extra), $status_code);
    }

    http_response_code($status_code);
    exit($message);
}

function respond_with_success(string $message, ?string $redirect = null, array $extra = []): void
{
    $normalized_redirect = normalize_redirect_path($redirect);

    if (wants_json_response()) {
        send_json_response(array_merge([
            'ok' => true,
            'message' => $message,
            'redirect' => $normalized_redirect,
        ], $extra));
    }

    if ($normalized_redirect) {
        header("Location: {$normalized_redirect}");
        exit();
    }

    exit($message);
}
