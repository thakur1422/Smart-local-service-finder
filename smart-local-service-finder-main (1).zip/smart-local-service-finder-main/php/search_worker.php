<?php
session_start();
include("db.php");

$q = trim($_GET['service'] ?? '');
$cat = trim($_GET['cat'] ?? '');

$where = "1=1";
$params = [];
$types = "";

if ($q) {
    $where .= " AND w.skill LIKE ?";
    $params[] = "%$q%";
    $types .= "s";
}

if ($cat) {
    $where .= " AND w.category_id = (SELECT id FROM categories WHERE slug = ?)";
    $params[] = $cat;
    $types .= "s";
}

$stmt = $conn->prepare("
    SELECT w.*, u.name, u.phone, u.city, c.name as category, AVG(r.rating) as avg_rating 
    FROM workers w 
    JOIN users u ON w.user_id = u.id 
    LEFT JOIN categories c ON w.category_id = c.id
    LEFT JOIN reviews r ON w.user_id = r.worker_id
    WHERE $where
    GROUP BY w.id
    ORDER BY avg_rating DESC, w.price_per_hour ASC
    LIMIT 12
");

if ($params) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='empty-state-card'>";
    echo "<span class='empty-state-kicker'>No match found</span>";
    echo "<h3>No professionals found</h3>";
    echo "<p>Try a broader service name or explore one of the popular service categories.</p>";
    echo "<a href='services.html' class='btn-primary'>Browse Services</a>";
    echo "</div>";
} else {
    while ($row = $result->fetch_assoc()) {
        $rating = $row['avg_rating'] ? round($row['avg_rating'], 1) : 'New';
        $displaySkill = htmlspecialchars($row['skill'] ?? $row['category'] ?? 'General Service');
        $workerName = htmlspecialchars($row['name']);
        $workerCity = htmlspecialchars($row['city'] ?? 'Your City');
        $workerPhone = htmlspecialchars($row['phone']);
        $hourlyRate = number_format((float) ($row['price_per_hour'] ?? 0), 0);
        $bookingLabel = json_encode($row['skill'] ?? $row['category'] ?? 'Service');
        $photo = !empty($row['photo']) ? "uploads/" . rawurlencode($row['photo']) : "images/avatar-placeholder.svg";

        echo "<article class='result-card'>";
        echo "<div class='result-card-main'>";
        echo "<img src='{$photo}' alt='Professional profile photo' class='result-avatar'>";

        echo "<div class='result-copy'>";
        echo "<div class='result-header'>";
        echo "<div>";
        echo "<h3>{$workerName}</h3>";
        echo "<p class='result-skill'>{$displaySkill}</p>";
        echo "</div>";
        echo "<span class='result-rating'>{$rating} &#9733;</span>";
        echo "</div>";

        echo "<div class='result-meta'>";
        echo "<span class='result-pill'>Rs. {$hourlyRate}/hr</span>";
        echo "<span class='result-pill'>{$workerCity}</span>";
        echo "<span class='result-pill'>Verified professional</span>";
        echo "</div>";
        echo "</div>";
        echo "</div>";

        echo "<div class='result-actions'>";
        echo "<a href='tel:{$workerPhone}' class='btn btn-secondary result-btn'>Call</a>";
        echo "<button onclick='bookWorker(" . (int) $row['user_id'] . ", {$bookingLabel})' class='btn btn-success result-btn'>Book Now</button>";
        echo "</div>";
        echo "</article>";
    }
}

$stmt->close();
?>
