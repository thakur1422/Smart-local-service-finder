<?php
session_start();
include("db.php");

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$sender_id = (int) $_SESSION['user_id'];
$booking_id = (int) ($_POST['booking_id'] ?? 0);
$message = trim($_POST['message'] ?? '');

if ($booking_id <= 0 || $message === '' || strlen($message) > 1000) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid input']);
    exit();
}

$access_stmt = $conn->prepare("
    SELECT b.user_id AS customer_id, w.user_id AS worker_user_id
    FROM bookings b
    JOIN workers w ON b.worker_id = w.id
    WHERE b.id = ?
");
$access_stmt->bind_param("i", $booking_id);
$access_stmt->execute();
$booking = $access_stmt->get_result()->fetch_assoc();
$access_stmt->close();

if (!$booking || ($booking['customer_id'] != $sender_id && $booking['worker_user_id'] != $sender_id)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$receiver_id = ($booking['customer_id'] == $sender_id) ? (int) $booking['worker_user_id'] : (int) $booking['customer_id'];

$stmt = $conn->prepare("
    INSERT INTO messages (booking_id, sender_id, receiver_id, message, created_at)
    VALUES (?, ?, ?, ?, NOW())
");
$stmt->bind_param("iiis", $booking_id, $sender_id, $receiver_id, $message);

if ($stmt->execute()) {
    echo json_encode(['status' => 'sent']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to send message']);
}

$stmt->close();
?>
