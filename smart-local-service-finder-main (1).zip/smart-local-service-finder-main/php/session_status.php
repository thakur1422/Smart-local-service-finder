<?php
session_start();
require_once 'response_helpers.php';

send_json_response([
    'ok' => true,
    'authenticated' => isset($_SESSION['user_id'], $_SESSION['role']),
    'user_id' => isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null,
    'role' => $_SESSION['role'] ?? null,
]);
