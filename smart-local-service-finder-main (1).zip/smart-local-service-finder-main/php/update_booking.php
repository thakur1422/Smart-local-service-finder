<?php
session_start();
include 'db.php';
require_once 'response_helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'worker') {
        respond_with_error('Access denied.', 403, [
            'redirect' => '../worker_login.html',
        ]);
    }

    $booking_id = (int) ($_POST['id'] ?? 0);
    $action = trim($_POST['action'] ?? '');
    $user_id = $_SESSION['user_id'];

    if ($booking_id <= 0 || !in_array($action, ['accept', 'reject'], true)) {
        respond_with_error('Invalid booking action.', 400, [
            'redirect' => '../worker/dashboard.php',
        ]);
    }

    // Verify ownership
    $stmt = $conn->prepare("SELECT b.*, w.user_id as worker_user_id FROM bookings b JOIN workers w ON b.worker_id = w.id WHERE b.id = ?");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();

    if (!$booking || (int) $booking['worker_user_id'] !== (int) $user_id) {
        respond_with_error('Unauthorized.', 403, [
            'redirect' => '../worker/dashboard.php',
        ]);
    }

    $status = ($action === 'accept') ? 'accepted' : 'rejected';

    try {
        $conn->begin_transaction();

        $update = $conn->prepare("UPDATE bookings SET `status` = '{$status}' WHERE id = ?");
        $update->bind_param("i", $booking_id);
        $update->execute();

        // Notify customer
        $message = ($action === 'accept') 
            ? "Booking #$booking_id ({$booking['service_type']}) accepted! Chat available."
            : "Booking #$booking_id ({$booking['service_type']}) rejected.";
        
        $notif = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif->bind_param("is", $booking['user_id'], $message);
        $notif->execute();
        $notif->close();

        $conn->commit();

        $verify_stmt = $conn->prepare("SELECT status FROM bookings WHERE id = ? LIMIT 1");
        $verify_stmt->bind_param("i", $booking_id);
        $verify_stmt->execute();
        $updated_booking = $verify_stmt->get_result()->fetch_assoc();
        $verify_stmt->close();

        if (($updated_booking['status'] ?? null) !== $status) {
            respond_with_error('Booking status could not be updated. Please try again.', 500);
        }

        respond_with_success(
            $action === 'accept' ? 'Booking accepted successfully.' : 'Booking rejected successfully.',
            null,
            [
                'booking_id' => $booking_id,
                'status' => $status,
            ]
        );
    } catch (Throwable $error) {
        $conn->rollback();
        respond_with_error('Booking update failed: ' . $error->getMessage(), 500);
    }
} else {
    respond_with_error('Invalid request.', 405);
}
?>

