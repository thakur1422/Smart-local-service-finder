<?php
session_start();
include("db.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'worker') {
    header("Location: ../worker_login.html?next=%2Fsmart-service-finder%2Fworker%2Fprofile.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$name = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$city = trim($_POST['city'] ?? '');
$skill = trim($_POST['skill'] ?? '');
$experience = (int) ($_POST['experience'] ?? 0);
$price = (float) ($_POST['price_per_hour'] ?? 0);
$availability = trim($_POST['availability'] ?? 'available');
$category_id = (int) ($_POST['category_id'] ?? 0);

$check = $conn->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id <> ?");
$check->bind_param("ssi", $email, $phone, $user_id);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    $check->close();
    die("Email or phone is already in use.");
}
$check->close();

$user_stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, email = ?, city = ? WHERE id = ?");
$user_stmt->bind_param("ssssi", $name, $phone, $email, $city, $user_id);
$user_stmt->execute();
$user_stmt->close();

$photo_name = null;
if (!empty($_FILES['photo']['name'])) {
    $allowed = ['jpg', 'jpeg', 'png'];
    $file_ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));

    if (!in_array($file_ext, $allowed, true)) {
        die("Only JPG, JPEG, and PNG files are allowed.");
    }

    if (!is_dir("../uploads")) {
        mkdir("../uploads", 0777, true);
    }

    $photo_name = time() . "_" . basename($_FILES['photo']['name']);
    $target_path = "../uploads/" . $photo_name;

    if (!move_uploaded_file($_FILES['photo']['tmp_name'], $target_path)) {
        die("Photo upload failed.");
    }
}

if ($photo_name !== null) {
    $stmt = $conn->prepare("
        UPDATE workers
        SET skill = ?, experience = ?, price_per_hour = ?, availability = ?, category_id = ?, photo = ?
        WHERE user_id = ?
    ");
    $stmt->bind_param("sidsisi", $skill, $experience, $price, $availability, $category_id, $photo_name, $user_id);
} else {
    $stmt = $conn->prepare("
        UPDATE workers
        SET skill = ?, experience = ?, price_per_hour = ?, availability = ?, category_id = ?
        WHERE user_id = ?
    ");
    $stmt->bind_param("sidsii", $skill, $experience, $price, $availability, $category_id, $user_id);
}

$stmt->execute();
$stmt->close();

header("Location: ../worker/profile.php?updated=1");
exit();
?>
