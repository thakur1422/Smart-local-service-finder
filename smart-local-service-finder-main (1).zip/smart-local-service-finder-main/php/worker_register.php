<?php
include("db.php");
require_once("response_helpers.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $skill = trim($_POST['skill'] ?? '');
    $experience = (int) ($_POST['experience'] ?? 0);
    $price_per_hour = (float) ($_POST['price_per_hour'] ?? 0);
    $category_id = (int) ($_POST['category_id'] ?? 0);

    if ($name === '' || $email === '' || $phone === '' || $password === '' || $city === '' || $skill === '' || $category_id <= 0) {
        respond_with_error("Please complete all required fields.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respond_with_error("Invalid email address.");
    }

    $check = $conn->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
    $check->bind_param("ss", $email, $phone);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        respond_with_error("Email or phone is already registered.", 409);
    }
    $check->close();

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $user_stmt = $conn->prepare("
        INSERT INTO users (name, email, password, phone, role, city, created_at)
        VALUES (?, ?, ?, ?, 'worker', ?, NOW())
    ");
    $user_stmt->bind_param("sssss", $name, $email, $password_hash, $phone, $city);
    $user_stmt->execute();
    $user_id = $user_stmt->insert_id;
    $user_stmt->close();

    $worker_stmt = $conn->prepare("
        INSERT INTO workers (user_id, skill, experience, price_per_hour, rating, latitude, longitude, availability, category_id)
        VALUES (?, ?, ?, ?, 0, 0, 0, 'available', ?)
    ");
    $worker_stmt->bind_param("isidi", $user_id, $skill, $experience, $price_per_hour, $category_id);

    if ($worker_stmt->execute()) {
        respond_with_success("Worker account created successfully. Please sign in.", "../worker_login.html");
    } else {
        respond_with_error("Worker registration failed: " . $worker_stmt->error, 500);
    }

    $worker_stmt->close();
    $conn->close();
}
?>
