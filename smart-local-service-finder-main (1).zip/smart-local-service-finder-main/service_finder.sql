-- Smart Service Finder schema
-- Updated to match the current site flows for categories, bookings, chat, and worker profiles.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `service_finder`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE `service_finder`;

DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `workers`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` enum('user','worker','admin') NOT NULL DEFAULT 'user',
  `city` varchar(80) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_phone_unique` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `image_url` text DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT 4.8,
  `jobs_count` int(11) DEFAULT 0,
  `starting_price` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `workers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `experience` int(11) NOT NULL DEFAULT 0,
  `price_per_hour` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rating` decimal(3,2) DEFAULT 0.00,
  `latitude` double DEFAULT 0,
  `longitude` double DEFAULT 0,
  `availability` enum('available','unavailable') DEFAULT 'available',
  `photo` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workers_user_id_idx` (`user_id`),
  KEY `workers_category_id_idx` (`category_id`),
  CONSTRAINT `workers_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `workers_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `service_type` varchar(100) NOT NULL,
  `booking_date` datetime NOT NULL,
  `time_slot` varchar(30) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','accepted','rejected','completed') DEFAULT 'pending',
  `estimated_price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bookings_user_id_idx` (`user_id`),
  KEY `bookings_worker_id_idx` (`worker_id`),
  CONSTRAINT `bookings_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_worker_fk` FOREIGN KEY (`worker_id`) REFERENCES `workers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `messages_booking_id_idx` (`booking_id`),
  KEY `messages_sender_id_idx` (`sender_id`),
  KEY `messages_receiver_id_idx` (`receiver_id`),
  CONSTRAINT `messages_booking_fk` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_sender_fk` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_receiver_fk` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read') NOT NULL DEFAULT 'unread',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_idx` (`user_id`),
  CONSTRAINT `notifications_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `worker_id` int(11) NOT NULL,
  `rating` decimal(2,1) NOT NULL,
  `comment` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_idx` (`user_id`),
  KEY `reviews_worker_id_idx` (`worker_id`),
  CONSTRAINT `reviews_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_worker_user_fk` FOREIGN KEY (`worker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `image_url`, `rating`, `jobs_count`, `starting_price`) VALUES
(1, 'Home Cleaning', 'home-cleaning', 'cleaning', 'https://images.unsplash.com/photo-1686178827149-6d55c72d81df?auto=format&fit=crop&fm=jpg&q=80&w=1200&h=900', 4.9, 12470, 999),
(2, 'Plumbing', 'plumbing', 'plumbing', 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&fm=jpg&q=80&w=1200&h=900', 4.8, 8470, 199),
(3, 'Electrical Work', 'electrical', 'electrical', 'https://images.unsplash.com/photo-1741388222137-c0d3007ec173?auto=format&fit=crop&fm=jpg&q=80&w=1200&h=900', 4.8, 6230, 299),
(4, 'AC Repair', 'ac-repair', 'ac', 'https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=800&h=600&fit=crop', 4.7, 4230, 499),
(5, 'Painter', 'painter', 'painting', 'https://images.pexels.com/photos/5493655/pexels-photo-5493655.jpeg?cs=srgb&dl=pexels-shkrabaanthony-5493655.jpg&fm=jpg', 4.8, 3120, 1599),
(6, 'Pest Control', 'pest-control', 'pest-control', 'https://images.pexels.com/photos/35303785/pexels-photo-35303785.jpeg?cs=srgb&dl=pexels-erknaygrdu-35303785.jpg&fm=jpg', 4.9, 2180, 899),
(7, 'Beautician', 'beautician', 'beauty', 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&h=600&fit=crop', 4.9, 8920, 599),
(8, 'Salon at Home', 'salon', 'salon', 'https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?w=800&h=600&fit=crop', 4.9, 6450, 499),
(9, 'Massage Therapy', 'massage', 'massage', 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&h=600&fit=crop', 4.8, 3780, 799),
(10, 'Car Wash at Home', 'car-wash', 'car-wash', 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&h=600&fit=crop', 4.7, 2340, 399),
(11, 'Carpentry', 'carpenter', 'carpentry', 'https://images.unsplash.com/photo-1519710164239-da123dc03ef4?w=800&h=600&fit=crop', 4.8, 1840, 349);

COMMIT;
