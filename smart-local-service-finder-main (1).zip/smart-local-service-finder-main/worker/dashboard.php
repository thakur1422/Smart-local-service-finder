<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'worker') {
    $next = rawurlencode('/smart-service-finder/worker/dashboard.php');
    header("Location: ../worker_login.html?next={$next}");
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

$worker_stmt = $conn->prepare("
    SELECT w.id, w.skill, w.experience, w.price_per_hour, w.availability, u.name, u.city
    FROM workers w
    JOIN users u ON w.user_id = u.id
    WHERE w.user_id = ?
");
$worker_stmt->bind_param("i", $user_id);
$worker_stmt->execute();
$worker = $worker_stmt->get_result()->fetch_assoc();
$worker_stmt->close();
$worker_id = (int) ($worker['id'] ?? 0);

$stats_stmt = $conn->prepare("
    SELECT
        COUNT(*) AS total_jobs,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_jobs,
        SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) AS accepted_jobs,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_jobs
    FROM bookings
    WHERE worker_id = ?
");
$stats_stmt->bind_param("i", $worker_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
$stats_stmt->close();

$pending_stmt = $conn->prepare("
    SELECT b.*, u.name AS customer_name, u.phone AS customer_phone
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    WHERE b.worker_id = ? AND b.status = 'pending'
    ORDER BY b.created_at DESC
");
$pending_stmt->bind_param("i", $worker_id);
$pending_stmt->execute();
$pending_jobs = $pending_stmt->get_result();

$accepted_stmt = $conn->prepare("
    SELECT b.*, u.name AS customer_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    WHERE b.worker_id = ? AND b.status IN ('accepted', 'completed')
    ORDER BY b.created_at DESC
    LIMIT 5
");
$accepted_stmt->bind_param("i", $worker_id);
$accepted_stmt->execute();
$accepted_jobs = $accepted_stmt->get_result();

$notif_stmt = $conn->prepare("
    SELECT message, status, created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 5
");
$notif_stmt->bind_param("i", $user_id);
$notif_stmt->execute();
$notifications = $notif_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Dashboard - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body
    class="app-page"
    data-dashboard-role="worker"
    data-dashboard-endpoint="../php/dashboard_snapshot.php"
    data-update-booking-endpoint="../php/update_booking.php"
>
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php" class="is-active">Dashboard</a>
                <a href="my-jobs.php">My Jobs</a>
                <a href="profile.php">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <span class="ui-eyebrow">Worker dashboard</span>
                <div class="panel-heading" style="margin-top: 1rem;">
                    <div>
                        <h1 style="margin: 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2.2rem, 4vw, 3.5rem);">
                            Welcome, <?= htmlspecialchars($worker['name'] ?? 'Professional') ?>
                        </h1>
                        <p>
                            <?= htmlspecialchars($worker['skill'] ?? 'General Service') ?>
                            <?php if (!empty($worker['city'])): ?> in <?= htmlspecialchars($worker['city']) ?><?php endif; ?>
                        </p>
                    </div>
                    <a href="profile.php" class="btn-primary">Update Profile</a>
                </div>

                <div class="stats-row">
                    <div class="stat-block">
                        <strong data-stat="pending_jobs"><?= (int) ($stats['pending_jobs'] ?? 0) ?></strong>
                        <span>Pending requests</span>
                    </div>
                    <div class="stat-block">
                        <strong data-stat="accepted_jobs"><?= (int) ($stats['accepted_jobs'] ?? 0) ?></strong>
                        <span>Accepted jobs</span>
                    </div>
                    <div class="stat-block">
                        <strong data-stat="price_per_hour">Rs. <?= number_format((float) ($worker['price_per_hour'] ?? 0), 0) ?>/hr</strong>
                        <span>Current rate</span>
                    </div>
                </div>
            </section>

            <section class="dashboard-grid">
                <div class="stack-grid">
                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Incoming work</span>
                                <h2 style="margin-top: 0.75rem;">Pending Booking Requests</h2>
                            </div>
                        </div>

                        <div class="info-list" id="worker-pending-jobs">
                            <?php if ($pending_jobs->num_rows === 0): ?>
                                <div class="list-empty">No pending booking requests right now.</div>
                            <?php else: ?>
                                <?php while ($job = $pending_jobs->fetch_assoc()): ?>
                                    <article class="info-item">
                                        <div class="panel-heading" style="margin-bottom: 0.5rem;">
                                            <div>
                                                <h3><?= htmlspecialchars($job['service_type']) ?></h3>
                                                <p>Customer: <?= htmlspecialchars($job['customer_name']) ?></p>
                                            </div>
                                            <span class="status pending">Pending</span>
                                        </div>
                                        <div class="meta-row">
                                            <span class="meta-pill">Booking #<?= (int) $job['id'] ?></span>
                                            <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($job['booking_date'])) ?></span>
                                            <span class="meta-pill"><?= htmlspecialchars($job['customer_phone']) ?></span>
                                        </div>
                                        <div class="actions-row">
                                            <form method="POST" action="../php/update_booking.php" data-ajax-form data-booking-action>
                                                <input type="hidden" name="id" value="<?= (int) $job['id'] ?>">
                                                <input type="hidden" name="action" value="accept">
                                                <button type="submit" class="btn-success" data-loading-text="Accepting...">Accept</button>
                                            </form>
                                            <form method="POST" action="../php/update_booking.php" data-ajax-form data-booking-action>
                                                <input type="hidden" name="id" value="<?= (int) $job['id'] ?>">
                                                <input type="hidden" name="action" value="reject">
                                                <button type="submit" class="btn btn-secondary" data-loading-text="Rejecting...">Reject</button>
                                            </form>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </section>

                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Ongoing work</span>
                                <h2 style="margin-top: 0.75rem;">Accepted and Completed Jobs</h2>
                            </div>
                            <a href="my-jobs.php" class="subtle-link">View all jobs</a>
                        </div>

                        <div class="info-list" id="worker-accepted-jobs">
                            <?php if ($accepted_jobs->num_rows === 0): ?>
                                <div class="list-empty">No accepted or completed jobs yet.</div>
                            <?php else: ?>
                                <?php while ($job = $accepted_jobs->fetch_assoc()): ?>
                                    <article class="info-item">
                                        <div class="panel-heading" style="margin-bottom: 0.5rem;">
                                            <div>
                                                <h3><?= htmlspecialchars($job['service_type']) ?></h3>
                                                <p>Customer: <?= htmlspecialchars($job['customer_name']) ?></p>
                                            </div>
                                            <span class="status <?= htmlspecialchars($job['status']) ?>">
                                                <?= ucfirst(htmlspecialchars($job['status'])) ?>
                                            </span>
                                        </div>
                                        <div class="meta-row">
                                            <span class="meta-pill">Booking #<?= (int) $job['id'] ?></span>
                                            <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($job['booking_date'])) ?></span>
                                        </div>
                                        <?php if ($job['status'] === 'accepted'): ?>
                                            <div class="actions-row">
                                                <a href="../chat.html?booking_id=<?= (int) $job['id'] ?>" class="btn-primary">Open Chat</a>
                                            </div>
                                        <?php endif; ?>
                                    </article>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </section>
                </div>

                <div class="stack-grid">
                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Profile snapshot</span>
                                <h2 style="margin-top: 0.75rem;">Your account</h2>
                            </div>
                        </div>
                        <div class="info-list">
                            <article class="info-item">
                                <h4>Primary skill</h4>
                                <p><?= htmlspecialchars($worker['skill'] ?? 'General Service') ?></p>
                            </article>
                            <article class="info-item">
                                <h4>Experience</h4>
                                <p><?= (int) ($worker['experience'] ?? 0) ?> years</p>
                            </article>
                            <article class="info-item">
                                <h4>Availability</h4>
                                <p><?= ucfirst(htmlspecialchars($worker['availability'] ?? 'available')) ?></p>
                            </article>
                        </div>
                    </section>

                    <section class="section-card">
                        <div class="panel-heading">
                            <div>
                                <span class="ui-eyebrow">Notifications</span>
                                <h2 style="margin-top: 0.75rem;">Latest updates</h2>
                            </div>
                        </div>
                        <div class="info-list" id="worker-notifications">
                            <?php if ($notifications->num_rows === 0): ?>
                                <div class="list-empty">No notifications yet.</div>
                            <?php else: ?>
                                <?php while ($notification = $notifications->fetch_assoc()): ?>
                                    <article class="info-item">
                                        <h4 style="margin-bottom: 0.35rem;">
                                            <?= htmlspecialchars($notification['status'] === 'unread' ? 'New update' : 'Earlier update') ?>
                                        </h4>
                                        <p><?= htmlspecialchars($notification['message']) ?></p>
                                        <div class="meta-row">
                                            <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($notification['created_at'])) ?></span>
                                        </div>
                                    </article>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </section>
                </div>
            </section>
        </div>
    </main>
    <script src="../js/app.js"></script>
</body>
</html>
