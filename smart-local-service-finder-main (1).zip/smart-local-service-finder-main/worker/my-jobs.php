<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'worker') {
    $next = rawurlencode('/smart-service-finder/worker/my-jobs.php');
    header("Location: ../worker_login.html?next={$next}");
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

$worker_id_stmt = $conn->prepare("SELECT id FROM workers WHERE user_id = ?");
$worker_id_stmt->bind_param("i", $user_id);
$worker_id_stmt->execute();
$worker = $worker_id_stmt->get_result()->fetch_assoc();
$worker_id_stmt->close();
$worker_id = (int) ($worker['id'] ?? 0);

$jobs_stmt = $conn->prepare("
    SELECT b.*, u.name AS customer_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    WHERE b.worker_id = ?
    ORDER BY b.created_at DESC
");
$jobs_stmt->bind_param("i", $worker_id);
$jobs_stmt->execute();
$jobs = $jobs_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Jobs - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="my-jobs.php" class="is-active">My Jobs</a>
                <a href="profile.php">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Worker history</span>
                        <h1 style="margin: 0.8rem 0 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2rem, 4vw, 3.25rem);">
                            My Jobs
                        </h1>
                    </div>
                    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                </div>
            </section>

            <section class="section-card">
                <div class="info-list">
                    <?php if ($jobs->num_rows === 0): ?>
                        <div class="list-empty">No jobs yet. New bookings will appear here as customers book your services.</div>
                    <?php else: ?>
                        <?php while ($job = $jobs->fetch_assoc()): ?>
                            <article class="info-item">
                                <div class="panel-heading" style="margin-bottom: 0.5rem;">
                                    <div>
                                        <h3><?= htmlspecialchars($job['service_type']) ?></h3>
                                        <p>Customer: <?= htmlspecialchars($job['customer_name']) ?></p>
                                    </div>
                                    <span class="status <?= htmlspecialchars($job['status']) ?>">
                                        <?= ucfirst(htmlspecialchars($job['status'])) ?>
                                    </span>
                                </div>

                                <div class="meta-row">
                                    <span class="meta-pill">Booking #<?= (int) $job['id'] ?></span>
                                    <span class="meta-pill"><?= date('M j, Y g:i A', strtotime($job['booking_date'])) ?></span>
                                    <?php if (!empty($job['estimated_price'])): ?>
                                        <span class="meta-pill">Rs. <?= number_format((float) $job['estimated_price'], 0) ?></span>
                                    <?php endif; ?>
                                </div>

                                <?php if ($job['status'] === 'accepted'): ?>
                                    <div class="actions-row">
                                        <a href="../chat.html?booking_id=<?= (int) $job['id'] ?>" class="btn-primary">Open Chat</a>
                                    </div>
                                <?php endif; ?>
                            </article>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>
</body>
</html>
