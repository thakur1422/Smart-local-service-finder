<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'worker') {
    $next = rawurlencode('/smart-service-finder/worker/profile.php');
    header("Location: ../worker_login.html?next={$next}");
    exit();
}

include '../php/db.php';
$user_id = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $skill = trim($_POST['skill'] ?? '');
    $experience = (int) ($_POST['experience'] ?? 0);
    $price_per_hour = (float) ($_POST['price_per_hour'] ?? 0);
    $availability = trim($_POST['availability'] ?? 'available');
    $category_id = (int) ($_POST['category_id'] ?? 0);

    if ($name !== '' && $phone !== '' && $email !== '' && $skill !== '') {
        $check = $conn->prepare("SELECT id FROM users WHERE (email = ? OR phone = ?) AND id <> ?");
        $check->bind_param("ssi", $email, $phone, $user_id);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $check->close();
            header('Location: profile.php?error=duplicate');
            exit();
        }

        $check->close();

        $user_update = $conn->prepare("UPDATE users SET name = ?, phone = ?, email = ?, city = ? WHERE id = ?");
        $user_update->bind_param("ssssi", $name, $phone, $email, $city, $user_id);
        $user_update->execute();
        $user_update->close();

        $worker_update = $conn->prepare("
            UPDATE workers
            SET skill = ?, experience = ?, price_per_hour = ?, availability = ?, category_id = ?
            WHERE user_id = ?
        ");
        $worker_update->bind_param("sidsii", $skill, $experience, $price_per_hour, $availability, $category_id, $user_id);
        $worker_update->execute();
        $worker_update->close();

        header('Location: profile.php?updated=1');
        exit();
    }
}

$stmt = $conn->prepare("
    SELECT u.name, u.email, u.phone, u.city, w.skill, w.experience, w.price_per_hour, w.availability, w.category_id
    FROM users u
    JOIN workers w ON u.id = w.user_id
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
$stmt->close();

$categories = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Profile - Smart Service Finder</title>
    <link rel="stylesheet" href="../css/app.css">
</head>
<body class="app-page">
    <header class="app-header">
        <div class="container app-nav">
            <a href="../index.html" class="app-brand">
                <span class="app-brand-mark">SF</span>
                <span class="app-brand-text">Smart Service Finder</span>
            </a>
            <div class="app-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="my-jobs.php">My Jobs</a>
                <a href="profile.php" class="is-active">Profile</a>
            </div>
            <a href="../php/logout.php" class="btn app-nav-cta">Logout</a>
        </div>
    </header>

    <main class="dashboard-section">
        <div class="container stack-grid">
            <section class="section-card">
                <div class="panel-heading">
                    <div>
                        <span class="ui-eyebrow">Profile settings</span>
                        <h1 style="margin: 0.8rem 0 0; font-family: 'Manrope', 'Inter', sans-serif; font-size: clamp(2rem, 4vw, 3.25rem);">
                            Worker Profile
                        </h1>
                        <p>Update your professional details so customers see accurate service information.</p>
                    </div>
                    <?php if (isset($_GET['updated'])): ?>
                        <span class="status completed">Profile updated</span>
                    <?php elseif (isset($_GET['error']) && $_GET['error'] === 'duplicate'): ?>
                        <span class="status rejected">Email or phone already in use</span>
                    <?php endif; ?>
                </div>
            </section>

            <section class="dashboard-grid">
                <div class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Edit details</span>
                            <h2 style="margin-top: 0.75rem;">Your professional profile</h2>
                        </div>
                    </div>

                    <form method="POST" class="form-stack" data-live-validate>
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="worker-profile-name">Full Name</label>
                                <input type="text" id="worker-profile-name" name="name" value="<?= htmlspecialchars($profile['name'] ?? '') ?>" required data-validate="name">
                            </div>
                            <div class="form-group">
                                <label for="worker-profile-phone">Phone Number</label>
                                <input type="text" id="worker-profile-phone" name="phone" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>" required data-validate="phone">
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="worker-profile-email">Email Address</label>
                                <input type="email" id="worker-profile-email" name="email" value="<?= htmlspecialchars($profile['email'] ?? '') ?>" required data-validate="email">
                            </div>
                            <div class="form-group">
                                <label for="worker-profile-city">City</label>
                                <input type="text" id="worker-profile-city" name="city" value="<?= htmlspecialchars($profile['city'] ?? '') ?>" required data-validate="text">
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="worker-profile-category">Service Category</label>
                                <select id="worker-profile-category" name="category_id" required data-validate="select">
                                    <option value="">Select a category</option>
                                    <?php while ($category = $categories->fetch_assoc()): ?>
                                        <option value="<?= (int) $category['id'] ?>" <?= (int) ($profile['category_id'] ?? 0) === (int) $category['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($category['name']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="worker-profile-skill">Primary Skill</label>
                                <input type="text" id="worker-profile-skill" name="skill" value="<?= htmlspecialchars($profile['skill'] ?? '') ?>" required data-validate="text">
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label for="worker-profile-experience">Experience</label>
                                <input type="number" id="worker-profile-experience" name="experience" min="0" value="<?= (int) ($profile['experience'] ?? 0) ?>" required data-validate="number">
                            </div>
                            <div class="form-group">
                                <label for="worker-profile-price">Price Per Hour</label>
                                <input type="number" id="worker-profile-price" name="price_per_hour" step="0.01" min="0" value="<?= htmlspecialchars((string) ($profile['price_per_hour'] ?? 0)) ?>" required data-validate="number">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="worker-profile-availability">Availability</label>
                            <select id="worker-profile-availability" name="availability" required data-validate="select">
                                <option value="available" <?= ($profile['availability'] ?? '') === 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="unavailable" <?= ($profile['availability'] ?? '') === 'unavailable' ? 'selected' : '' ?>>Unavailable</option>
                            </select>
                        </div>

                        <button type="submit" class="btn-primary">Save Changes</button>
                    </form>
                </div>

                <aside class="section-card">
                    <div class="panel-heading">
                        <div>
                            <span class="ui-eyebrow">Profile snapshot</span>
                            <h2 style="margin-top: 0.75rem;">Professional summary</h2>
                        </div>
                    </div>
                    <div class="info-list">
                        <article class="info-item">
                            <h4>Skill</h4>
                            <p><?= htmlspecialchars($profile['skill'] ?? '') ?></p>
                        </article>
                        <article class="info-item">
                            <h4>Rate</h4>
                            <p>Rs. <?= number_format((float) ($profile['price_per_hour'] ?? 0), 0) ?>/hr</p>
                        </article>
                        <article class="info-item">
                            <h4>Availability</h4>
                            <p><?= ucfirst(htmlspecialchars($profile['availability'] ?? 'available')) ?></p>
                        </article>
                    </div>
                </aside>
            </section>
        </div>
    </main>
    <script src="../js/app.js"></script>
</body>
</html>
